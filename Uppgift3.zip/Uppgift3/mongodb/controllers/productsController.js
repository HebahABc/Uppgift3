const express = require('express')
const controller = express.Router()

const productSchema = require('../schemas/productSchema')



//unsecured routes
controller.route('/').get(async (req, res) => {
    try {
        const products = await productSchema.find()
        const list = []
        for (let product of products)
        {
            list.push({
                articleNumber: product.id,
                name: product.name,
                description: product.description,
                category: product.category,
                price: product.price,
                rating: product.rating,
                tag: product.tag,
                imageName: product.imageName
            })
        }
        res.status(200).json(list)
    }
    catch {
        res.status(400).json()
    }
})

controller.route('/:tag').get(async(req, res) => {
    const list = []
    const products = await ProductSchema.find({tag: req.params.tag})
    if (products)
    {
        for (let product of products)
        {
            list.push({
                articleNumber: product.id,
                name: product.name,
                description: product.description,
                category: product.category,
                price: product.price,
                rating: product.rating,
                tag: product.tag,
                imageName: product.imageName
            })
        }
        res.status(200).json(list)
    }
    else
        res.status(400).json()
})


controller.route('/:tag/:take').get(async(req, res) => {
    const list = []
    const products = await ProductSchema.find({tag: req.params.tag}).limit(req.params.take)
    if (products)
    {
        for (let product of products)
        {
            list.push({
                articleNumber: product.id,
                name: product.name,
                description: product.description,
                category: product.category,
                price: product.price,
                rating: product.rating,
                tag: product.tag,
                imageName: product.imageName
            })
        }
        res.status(200).json(list)
    }
    else
        res.status(400).json()
})

controller.route('/product/details/:articleNumber').get(async(req, res) =>{
    const product = await productSchema.findById(req.params.articleNumber)
    if (product)
        res.status(200).json(product)
    else
        res.status(404).json()
})



//secured routes
controller.route('/').post(async(req, res) => {
    const {name, description, category, price, rating, tag, imageName} = req.body
    if (!name || !price)
        res.status(400).json({text: 'name and price are required fields'})
    
    const is_exist = await productSchema.findOne({name})
    if (is_exist)
        res.status(400).json({text: 'a product with the same name already exists'})
    else {
        const product = await productSchema.create({
            name,
            description,
            category,
            price,
            rating,
            tag,
            imageName
        })
        if (product)
            res.status(201).json({text: `product ${product._id} was added successfully`})
        else
            res.status(400).json({text: 'something went wrong'})
    }
})


controller.route('/:articleNumber').delete(async(req, res)=> {
    if (!req.params.articleNumber)
        res.status(400).json({text: 'no article number was specificed'})
    else{
        const item = await productSchema.findById(req.params.articleNumber)
        if (item){
            await productSchema.deleteOne(item)
        res.status(200).json({text: 'product was deleted successfully'})
        }
        else
            res.status(400).json({text: 'product was not found'})
    }
})

    
controller.route('/:articleNumber').patch(async(req, res)=> {
    await productSchema.findByIdAndUpdate(req.params.articleNumber, req.body, {new: true}).then((product) =>{
        if (!product){
            res.status(400).json()   
        }
        res.status(200).json({text: `product ${req.params.articleNumber} was updated successfully`})
    })
    .catch(error => {
        res.status(500).json(error)
    })
})





module.exports = controller