import React from 'react'

const WishList : React.FC = () => {
  document.title = 'Wish List | Fixxo.'
  return (
    <></>
  )
}

export default WishList