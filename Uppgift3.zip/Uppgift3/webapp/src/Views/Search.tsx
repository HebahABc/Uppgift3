import React from 'react'

const Search : React.FC = () => {
  document.title = 'Search | Fixxo.'
  return (
    <div>
    </div>
  )
}

export default Search