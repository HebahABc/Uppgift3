import React from 'react'

const Compare : React.FC = () => {
  document.title = 'Compare items | Fixxo.'
  return (
    <div>
    </div>
  )
}

export default Compare