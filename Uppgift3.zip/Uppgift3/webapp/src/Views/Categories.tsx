import React from 'react'
import CurrentPage from '../Components/CurrentPage'


const Categories : React.FC = () => {
  document.title = 'Categories | Fixxo.'
  return (
    <>
    <CurrentPage cpage=' Categories'/>
    </>
  )
}

export default Categories