import React, {useState} from 'react'
import AlertNotification from '../Components/AlertNotification'
import { validateEmail, validateText } from '../Utilities/Validation'

interface FormDataType{
    name: string
    email: string
    comment: string
}

const ContactForm: React.FC = () => 
{
    const DEFAULT_VALUES : FormDataType = {name:'', email:'', comment:''}
    const [formData, setFormData ] = useState <FormDataType>(DEFAULT_VALUES)
    const [errors, setErrors] = useState<FormDataType>(DEFAULT_VALUES)
    const [submitted, setSubmitted] = useState<boolean>(false)
    const [failedSubmit, setFailedSubmit] = useState<boolean>(false)



    const handleChange = (e:React.ChangeEvent<HTMLInputElement>) =>{
        const {id, value} = e.target
        setFormData({...formData, [id]:value})
        if (id === 'name')
            setErrors({...errors, [id]:validateText(id, value)})
        if (id === 'email')
            setErrors({...errors, [id]:validateEmail(id, value)})
        setFailedSubmit(false)
        setSubmitted(false)
    }

    const handleTextAreaChange = (e:React.ChangeEvent<HTMLTextAreaElement>) =>{
        const {id, value} = e.target
        setFormData({...formData, [id]:value})
        if (id === 'comment')
            setErrors({...errors, [id]:validateText(id, value, 5)})
        setFailedSubmit(false)
        setSubmitted(false)
    }

    const handleSubmit = async (e:React.FormEvent<HTMLFormElement>) => 
    {
        e.preventDefault()
        let name= formData.name
        let mail= formData.email
        let comment = formData.comment
        
        if (formData.name !== '' && formData.email !== '' && formData.comment !=='')
        {
            if (errors.name == null && errors.email == null && errors.comment == null )
            {
                const res = await fetch('https://win22-webapi.azurewebsites.net/api/contactform', {
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify(formData)})
                if (res.status === 200)
                {
                    setSubmitted(true)
                    setFailedSubmit(false)
                    setFormData(DEFAULT_VALUES)
                } 
                else 
                {
                    setSubmitted(false)
                    setFailedSubmit(true)     
                }
            }
        }
    }   
    return(
        <section className='ContactForm'>
        <div className='container'>
            {submitted ? (<AlertNotification alertType="success" title="Thank you for your comment" text="We will contact you as soon as possible" />) : (<></>)}
            {failedSubmit ? (<AlertNotification alertType="danger" title="Something went wrong!" text="We couldn't submit your comments right now" />) : (<></>)}
            <h2>Contact Us </h2>
            <form id='cForm' onSubmit={(e) => handleSubmit(e)} noValidate>
                <div>
                    <input id='name' className={(errors.name?'error':'')} type='text' placeholder='Your Name' value={formData.name} onChange={(e) => handleChange(e)}/>
                    <div className='errorMessage'>{errors.name}</div>
                </div>
                <div>
                    <input id='email' className={(errors.email ? 'error' : '')} type='email' placeholder='Your mail' value={formData.email} onChange={(e) => handleChange(e)}/>
                    <div className='errorMessage'>{errors.email}</div>
                </div>
                <div className='textArea'>
                    <textarea id='comment' className={(errors.comment ? 'error' : '')} style={(errors.comment ? {border: '1px solid #FF7373'}: {} )} placeholder='Comments' value={formData.comment} onChange={(e) => handleTextAreaChange(e)} />
                    <div className='errorMessage'>{errors.comment}</div>
                </div>
                <div>
                    <button className='send' type='submit'>Post Comments</button>
                    <div className='errorMessage'></div>
                </div>
            </form> 
        </div>
    </section>
    ) 
}

                

export default ContactForm
