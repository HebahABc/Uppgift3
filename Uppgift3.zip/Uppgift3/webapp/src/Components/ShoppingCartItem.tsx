
import {ShoppingCartContextType, useShoppingCart} from '../Context/ShoppingCartContext'
import { CartItem } from '../Models/ShoppingCartModels'
import { currencyFormatter } from './CurrenyFormat'


interface SHCI{
    item: CartItem
}

const ShoppingCartItem : React.FC<SHCI> = ({item}) => {
    const {increment, decrement, remove} = useShoppingCart() as ShoppingCartContextType
    return (
        <div className='shoppingcart-item'>
            <div className='item-image'>
                <img src={item.product.imageName} alt={item.product.name}/>
            </div>
            <div className='item-info'>
                <div className='item-name'>{item.product.name}</div>
                <div className='item-quantity'>
                    <div className='item-quantity-box'>
                        <div className="btn-group btn-group-sm" role="group" aria-label="Small button group">
                            <button type="button" className="btn btn-outline-dark" onClick={() => decrement(item)}>-</button>
                            <span>{item.quantity}</span>
                            <button type="button" className="btn btn-outline-dark" onClick={() => increment(item)} >+</button>
                        </div>
                    </div>    
                </div>
                <div className='item-price'>
                    <div>{currencyFormatter(item.product.price * item.quantity)}</div>
                    <button onClick={() => remove(item.articleNumber)}><i className="fa-solid fa-trash"></i></button>
                </div>
            </div>
        </div>
    )
}

export default ShoppingCartItem