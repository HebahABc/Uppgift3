import React, {useState} from 'react'
import { ShoppingCartContextType, useShoppingCart } from '../Context/ShoppingCartContext'
import ShoppingBarIcons from './ShoppingBarIcons'



const ShoppingBar : React.FC = () => {
  const [toggle, setToggle] = useState(false)
  const {totalQuantity} = useShoppingCart() as ShoppingCartContextType
  const toggleHandle = () => {
    setToggle(!toggle)
  }
  
  return (
    <div className="shopping-bar">
      <div className='shopping-bar-child'>
        <ShoppingBarIcons link="/Search" icon="fa-solid fa-search"/>
        <ShoppingBarIcons link="/Compare" icon="fa-solid fa-code-compare"/>
        <ShoppingBarIcons link="/WishList" icon="fa-regular fa-heart" quantity={2}/>
        <button className="CartBtn" type="button" data-bs-toggle="offcanvas" data-bs-target="#shoppingCart" aria-controls="shoppingCart">
        <i className="fa-solid fa-cart-shopping">
            <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-theme">{totalQuantity}</span>
            </i>
        </button>
        <button className='toggle-btn' onClick={toggleHandle}>
          <i className='fas fa-bars'></i>
        </button>

        
        
      </div>  
    </div>
  )
}

export default ShoppingBar



