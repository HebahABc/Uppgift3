import React from 'react';
import {NavLink} from 'react-router-dom'; 
import { ShoppingCartContextType, useShoppingCart } from '../Context/ShoppingCartContext';
import { currencyFormatter } from './CurrenyFormat';
import { ProductItem } from '../Models/ProductModels';
import { CartItem } from '../Models/ShoppingCartModels';



interface ProductCardType{
    item: ProductItem
}
const ProductCard : React.FC <ProductCardType>= ({item}) => {
    const {increment} = useShoppingCart() as ShoppingCartContextType
    //const url = "../Porducts-Images/"+item.imageName
  return (
    
    <div className="col">
            <div className='grid-cells'>
                <div className="Card">
                    <img id='imgCard' src={item.imageName} alt={item.name}></img>
                    <div className="card-menu">
                        <div><a href="#"><i className="fa-regular fa-heart" ></i></a></div>
                        <div><a href="#"><i className="fa-solid fa-code-compare"></i></a></div>
                        <div onClick={() => increment({
                            articleNumber: item.articleNumber, product: item,
                            quantity: 0
                        })}><a href="#"><i className="fa fa-shopping-bag"></i></a></div>
                    </div>
                    
                    <div className="background">
                            <NavLink className="card_body" to="/Products"> QUICK VIEW </NavLink>
                    </div>
                </div>
                <div id="specification">
                    <div id="Category">{item.category}</div>
                    <div id="name"><b>{item.name}</b></div>
                    <div id="stars">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                    </div>
                    <div id="price"><b>{currencyFormatter(item.price)}</b></div>
                </div>
            </div>
        </div>
  );
}

export default ProductCard;