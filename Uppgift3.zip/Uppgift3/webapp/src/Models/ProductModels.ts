export interface ProductItem{
    tag: string
    imageName: string
    name:string
    articleNumber: string
    description: string
    category: string
    price: number
}

