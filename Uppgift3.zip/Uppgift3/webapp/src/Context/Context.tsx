import {createContext } from 'react';

//export interface productContextType{}


export const productContext = createContext( []);
export const FeaturedProductsContext = createContext( []);
export const GridProductsContext = createContext( []);
export const GridProductsContext2 = createContext( []);



