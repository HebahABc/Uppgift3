export const validateText = (elementName: string, value: string, minLength: number= 2) =>{
    if (value.length == 0)
        return `${elementName} is required`
    else if (value.length < minLength)
        return `${elementName} must contain at least ${minLength} characters`
    else
        return ''
}

export const validateEmail = (elementName: string, value: string, regExp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/) =>{
    if (value.length == 0)
        return `${elementName} is required`
    else if (!regExp.test(value))
        return `${elementName} must be a valid e-mail form`
    else
        return ''
}


